import random
import pandas as pd
pi = []
ti = []
di = []
Di = []
for i in range(5):

    n = int(input('enter the range'))
    for i in range(n):
        production_rate = random.randint(40,150)
        processing_time = random.randint(1, 20)
        release_date = random.randint(1, 15)
        due_date = random.randint(1, 30)
        pi.append(production_rate)
        ti.append(processing_time)
        di.append(release_date)
        Di.append(due_date)
        
    dict = dict(production_rate=pi, processing_time=ti, release_date=di, due_date=Di)
    df = pd.DataFrame(dict)

    df.to_csv(r'C:\Users\reddy\Documents\rig scheduling\random generator values\hmpt_datasets\sample_hmpt_' +str(n)+'.csv')
    print(df)
    pi.clear()
    ti.clear()
    di.clear()
    Di.clear()
    del dict
